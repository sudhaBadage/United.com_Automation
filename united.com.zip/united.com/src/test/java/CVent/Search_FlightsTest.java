package CVent;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import junit.framework.Assert;

public class Search_FlightsTest {

	WebDriver driver;
	flightsRepositoryTest FR;
	
	/*Before starting testcase execution -
	 1. Initialize the driver to automate the Web application
	 2. Get URL of a application from testng.xml file
	 3. Create object for a repository file to Access WebElements of Web application*/
	@Parameters({"URL"})
	@BeforeClass
	public void openBrowser(String URL)
	{
		System.setProperty("webdriver.chrome.driver","chromedriver");
		driver = new ChromeDriver();
		driver.get(URL);
		String CurrentWindow = driver.getWindowHandle();
		driver.switchTo().window(CurrentWindow);
		driver.manage().timeouts().implicitlyWait(4,TimeUnit.SECONDS);
		FR = new flightsRepositoryTest(driver);
	}
	
	//Test to automate flight searches
	//Using Data provider to provide parameters to Testcase
	@Test(dataProvider="flightInfo")
	public void searchFlights(String trip,String date) throws InterruptedException
	{
		//1. Search for Round-Trip flights with fixed dates
		if(trip.contains("Round")&&date.contains("Fixed"))
		{
			FR.Origin().sendKeys("Portland");
			FR.Destination().sendKeys("New york");
			FR.DepartureDate().sendKeys("Feb 21");
			FR.ReturnDate().sendKeys("Feb 25");
			FR.FindFlight().click();
			driver.navigate().back();
		}
		// 2. Search for One-Way flights with fixed dates
		else if(trip.contains("One")&&date.contains("Fixed"))
		{
			FR.OneWay().click();
			FR.FindFlight().click();
			driver.navigate().back();
			
		}
		//3. Search for Round-Trip flights with flexible dates
		else if(trip.contains("Round")&&date.contains("Flexible"))
		{
			FR.Round().click();
			FR.CalenderShop().click();
			FR.FindFlight().click();
			driver.navigate().back();
		}
		//4. Search for One-Way flights with flexible dates
		else if(trip.contains("One")&&date.contains("Flexible"))
		{
			FR.OneWay().click();
			FR.FindFlight().click();
			driver.navigate().back();
		}
	}
	
	//Providing different parameters to my testcase using DataProvider
	@DataProvider
	public Object[][] flightInfo()
	{
		Object[][] info = new Object[4][2];
		info[0][0] = "Round-Trip";
		info[0][1] = "Fixed-date";
		info[1][0] = "One-way";
		info[1][1] = "Fixed-date";
		info[2][0] = "Round-Trip";
		info[2][1] = "Flexible-date";
		info[3][0] = "One-way";
		info[3][1] = "Flexible-date";
		return info;
		
	}
	
	//Close the driver after execution
	@AfterSuite
	public void closeDriver() throws InterruptedException
	{
		driver.quit();
	}
}
