package CVent;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class flightsRepositoryTest {
	
	/*Implementing Page object pattern concept here - 
	By defining all the web elements related to my testcases in a different repository file*/
	WebDriver driver;

	public flightsRepositoryTest(WebDriver driver) {
		this.driver = driver;
	}
	
	//WebElement location
	By origin = By.id("bookFlightOriginInput");
	By destination = By.id("bookFlightDestinationInput");
	By departureDate = By.id("DepartDate");
	By returnDate = By.id("ReturnDate");
	By oneWay = By.xpath("//div[@class='app-components-BookFlightForm-bookFlightForm__radioContainer--3WXQM']//label[2]//span[2]");
	By round = By.xpath("//div[@class='app-components-BookFlightForm-bookFlightForm__radioContainer--3WXQM']//label[1]//span[2]");
	By findFlight = By.xpath("//span[contains(text(),'Find flights')]");
	By calenderShop = By.xpath("//span[contains(text(),'Calendar shop')]");
	
	//Finding WebElements through following functions
	public WebElement Origin()
	{
		return driver.findElement(origin);
	}
	
	public WebElement Destination()
	{
		return driver.findElement(destination);
	}
	
	public WebElement DepartureDate()
	{
		return driver.findElement(departureDate);
	}
	
	public WebElement ReturnDate()
	{
		return driver.findElement(returnDate);
	}
	
	public WebElement OneWay()
	{
		return driver.findElement(oneWay);
	}
	
	public WebElement Round()
	{
		return driver.findElement(round);
	}
	
	public WebElement FindFlight()
	{
		return driver.findElement(findFlight);
	}
	
	public WebElement CalenderShop()
	{
		return driver.findElement(calenderShop);
	}
	

}
